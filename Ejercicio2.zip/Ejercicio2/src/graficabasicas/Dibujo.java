package graficabasicas;
import java.awt.Graphics;


public class Dibujo {
    public static void HacerLinea( Graphics g, int x1, int y1, int x2, int y2)
            {
              g.drawLine(y2, y1, x2, y2);
              
            }
        public static void HacerCuadro( Graphics g, int x1, int y1, int x2, int y2)
        {
            g.drawRect(y2, x1, x2, y2);
        }
        public static void HacerCirculo( Graphics g)
        {
            g.fillOval(300, 0, 180, 180);
        }
        public static void HacerOvalo( Graphics g)
        {
            g.fillOval(600, 220, 180, 100);
        }
        public static void HacerRecta( Graphics g, int x1, int y1, int x2, int y2)
        {
            g.drawRect(y2, x1, x2, y2);
        
}
}
